<?php
$con=mysqli_connect("localhost","root","","hostel");

if(mysqli_connect_errno()){
 echo "Connection failed" .mysqli_connect_errno();
}
?>