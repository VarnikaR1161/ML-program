<!DOCTYPE html>
<html>
    <head>
        <title>About info</title>
    </head>
    <body bgcolor=" lightgray" title="black">
    <img src="about.jpg" alt="HOSTEL MANGEMENT" class="my-8 mx-auto rounded-md shadow-md" width="300"> 
<center>
        <p>
            <h1>WELCOME  TO HOSTEL MANGEMENT</h1>
            <h2>HOSTEL LIFE IS AN ADVENTURE WHERE EVERY DAY IS A NEW EXPERIRNCE</h2>
            <h2> A hostel management system is software developed for managing various activities in the hostel.
             It manages activities including the student information, room information, mess bills, 
             room allocation details, fee details and tracking of the number of students and availability of students.</h2>
  
        </p>
</center>
    </body>
</html>