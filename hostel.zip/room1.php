<!DOCTYPE html>
<html>
    <head>
        <title>ROOM INFO</title>
    </head>
    <body bgcolor="beige" text="black">
        <p>
            <center>
            <h1>WELCOME  TO HOSTEL MANGEMENT</h1>
            </center>
            <h3>Keeps a check on the daily issues regarding the hostel infrastructure,the housekeeping issues,mess facilities,etc
                Ensures an enriching stay at the campus.Organizes fun-packed events and food-carnivals.Coordinates with other clubs and 
                committees for the successful condut of various events.hostels offer facilities such as fully-equipped cateen , rooms, 
                Food,Fan,Bed,Cupboard,A/C and non A/c ,washingmachine,etc.Additionally, because the environment is much more laid-back 
                and collaborative, the hostel itself often hosts parties and organizes tours around the area with guests.
                A hostel is a place where students live to study or for work. It is usually supervised by a hostel manager 
                and residents. Students living in hostels experience their hostel life. 
                These hostels eventually became their homes.</h3>
<h2>
 To Maintain Cleanliness In Hostel</h2>
 <h3>
<h3>*Regular cleaning schedule</h3>
<h3>*Designated storage spaces</h3>
<h3>*Food storage and disposal</h3>
<h3>*Laundry management</h3>
<h3>*Personal hygiene</h3>
<h3>*Proper disposal of waste</h3>
<h3>*Inspections and evaluations</h3>

</h3>         
        </p>
    </body>
</html>