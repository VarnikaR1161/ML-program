<!DOCTYPE html>
<html>
    <head>
        <title>Contact info</title>
    </head>
    <body bgcolor=" lightgray" title="black">
    <center>
        <p>
            <h1>WELCOME  TO HOSTEL MANGEMENT</h1>
            <h1>contact number - +91 88111007870</h1>
               <h2>email- vardee@hms.in</h2>
        </p>
    </center>
    </body>
</html>