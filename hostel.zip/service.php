<!DOCTYPE html>
<html>
    <head>
        <title>SERVICES info</title>
    </head>
    <body bgcolor=" lightgray" title="black">
    
    <center>
        <p>
            <h1>WELCOME  TO HOSTEL MANGEMENT</h1>
            <h2>*Free wifi for students</h2>
            <h2>*Clean Servicers</h2>
            <h2>*Velondary Servicers</h2>
            <h2>*FirstAid(medical Servicers)</h2>
            <h2>*Will be provide Sanitary pads</h2>
            <h2>*Three times food will be providing</h2>  
               
        </p>
    </center>
    </body>
</html>